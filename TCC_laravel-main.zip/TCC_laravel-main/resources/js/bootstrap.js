import axios from 'axios';
import 'bootstrap';
window.axios = axios;

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
require('bootstrap/dist/js/bootstrap.bundle');
